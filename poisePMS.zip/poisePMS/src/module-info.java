/**
 * 
 */
/**
 * 
 */
module poisePMS {
		requires java.sql;	requires java.desktop;
		
}